// global.d.ts
declare module '*.svelte' {
    export { SvelteComponentDev as default } from 'svelte/internal';
}
