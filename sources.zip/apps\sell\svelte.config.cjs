const adapter = require('@sveltejs/adapter-node');
const { resolve } = require('path');
const { vitePreprocess } = require('@sveltejs/kit/vite');

/** @type {import('@sveltejs/kit').Config} */
module.exports = {
  preprocess: vitePreprocess(),
  kit: {
    adapter: adapter(),
    alias: {
      $lib: resolve('./src/lib'),
      $routes: resolve('./src/routes'),
      '@shared': resolve('../shared')
    }
  }
};
