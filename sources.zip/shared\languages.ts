export enum Languages {
    EN = 'en',
    FR = 'fr',
  }
  