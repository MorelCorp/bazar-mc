<script lang="ts">
    export let form;
  </script>
  
  
  <slot {form} />
  