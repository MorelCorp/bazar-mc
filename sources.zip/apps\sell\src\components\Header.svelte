<script lang="ts">
  import { setupI18n, _ } from '@shared/i18n';
  
  // Initialize i18n
  setupI18n();

  export let title = "Welcome to the Bazaar Entry";
</script>

<header>
  <h1>{title}</h1>
</header>

<style>
  header {
    text-align: center;
    margin-bottom: 2rem;
  }
</style>
