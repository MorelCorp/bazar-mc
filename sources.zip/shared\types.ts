export interface Game {
    title: string;
    price: number;
    sold: boolean;
  }
  
  export interface User {
    name: string;
    email: string;
  }
